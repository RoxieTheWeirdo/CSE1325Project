import java.io.BufferedReader;      //for titletext.txt
import java.io.FileReader;          //titletext.txt
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Arrays;
import java.util.List;
public class Main {
    public static Player Pl = new Player();     //stats found in Player.java
    public static GameData Gm = new GameData();     //Use of functions in GameData.java
    public static GameData.Bomb B = Gm.getBomb();   //Use of the bomb object
    public static char[][] currentMaze = null;      //currentMaze used throughout entire program
    public static char[][] baseMaze = null;         //baseMaze data (currentMaze can change throughout)
    public static Scanner sc = new Scanner(System.in);
    public static List<GameData.Thief> T;           //Thief data
    static int[] fallingCeilling = new int[3]; //holds coordinates for the trap
    public static void loadBaseMaze() {
        switch (Pl.LVL) {
            case 1:
                baseMaze = new char[][]{           //level 1
                        {'█', '█', '█', '█', '█', '█', '█', '█', '█', '█', '█', '█', 'X', '█',},
                        {'█', '-', '-', '-', '-', '█', '█', '-', '█', '-', '█', '█', '-', '█',},
                        {'█', '-', '█', '█', '█', '█', '█', '-', '█', '-', '█', '-', '-', '█',},
                        {'█', '-', '█', '-', '-', '-', '█', '-', '-', '-', '█', '-', '-', '█',},
                        {'█', '-', '█', '-', '-', '-', '█', '█', '█', '-', '█', '-', '-', '█',},
                        {'█', '-', '█', '-', '-', '-', '-', '-', '-', '-', '█', '-', '-', '█',},
                        {'█', '-', '█', '-', '█', '-', '█', '█', '█', '-', '█', '-', '-', '█',},
                        {'█', '-', '█', '-', '█', '-', '█', '-', '█', '-', '█', '-', '-', '█',},
                        {'█', '-', '-', '-', '█', '-', '█', '-', '█', '-', '-', '-', '-', '█',},
                        {'█', '-', '-', '-', '█', '-', '█', '-', '█', '-', '█', '█', '-', '█',},
                        {'█', '█', '█', '█', '█', '-', '█', '-', '█', '-', '█', '-', '-', '█',},
                        {'█', '-', 'V', '-', '-', '-', '█', 'K', '-', '-', '█', '-', '-', '█',},
                        {'█', '-', '█', '█', '█', '█', '█', '-', '█', '-', '█', '-', '-', '█',},
                        {'█', '-', '█', '█', '█', '█', '█', '-', '█', '█', '█', '█', '█', '█',},
                        {'█', '-', '█', '█', '█', '█', '█', '█', '█', '█', '█', '█', '█', '█',}
                };
                break;
            case 2:
                baseMaze = new char[][]{           //level 2
                        {'█', '█', '█', '█', '█', '█', '█', '█', '█', '-', '-', '-', '-', '█',},
                        {'█', '-', '-', '-', '-', '-', '█', '-', '▓', '-', '█', '█', '-', '█',},
                        {'█', '-', '█', '-', '-', '-', '█', 'K', '▓', '-', '-', '█', '█', '█',},
                        {'█', '-', '█', '-', '-', '-', '-', '-', '▓', '-', '-', '-', '-', '█',},
                        {'█', '-', '█', '█', '█', '█', '█', '█', '█', '-', '█', '-', 'B', '█',},
                        {'█', '-', '█', '-', '-', '-', '█', '-', '-', '-', '█', '█', '-', '█',},
                        {'█', '-', '█', '-', '-', '-', '█', '-', '█', '-', '█', '█', '-', '█',},
                        {'█', '-', '█', '-', '-', '-', '█', '-', '█', '-', '█', '-', '-', '█',},
                        {'█', '-', '-', '-', '█', '-', '█', '-', '█', '-', '█', '-', '-', '█',},
                        {'█', '-', '-', '-', '█', '-', '█', '-', '█', '-', '█', '-', '-', '█',},
                        {'█', '-', '█', '█', '█', 'V', '█', 'I', '█', '-', '█', '-', '-', '█',},
                        {'█', '-', '▓', '-', '▓', '-', '█', '-', '-', '-', '█', '-', '-', '█',},
                        {'█', '-', '▓', 'X', '▓', '-', '-', '-', '█', 'B', '█', '-', 'V', '█',},
                        {'█', '-', '▓', '█', '█', '█', '-', '-', '█', '█', '█', '█', '█', '█',},
                        {'█', '█', '█', '█', '█', '█', '█', '█', '█', '█', '█', '█', '█', '█',}
                };
                spawnThief('N', 12, 9, "");
                break;
            case 3:
                baseMaze = new char[][]{           //level 3
                        {'█', '█', '█', '█', '█', '█', '█', '█', '█', '█', '█', '█', '█', '█',},
                        {'█', '-', '-', '-', '-', 'V', '█', 'V', '-', '-', 'I', '-', '-', '█',},
                        {'█', 'B', '-', '█', '█', '█', '█', '█', '█', '█', '█', '█', '-', '█',},
                        {'█', 'I', '-', '-', '-', '-', '-', '-', '-', '█', '-', '█', '-', '█',},
                        {'█', '█', '-', '-', '-', '-', '-', '-', '-', 'M', '-', '█', '-', '█',},
                        {'█', '█', '-', '-', '▓', '▓', '█', '█', '█', '█', '-', '-', '-', '█',},
                        {'█', '-', '-', '-', '█', '-', '▓', '-', '█', '-', '-', '-', '-', '█',},
                        {'█', '-', '-', '-', '-', '-', '▓', 'X', '█', '-', '█', '-', '-', '█',},
                        {'█', '-', '-', '-', '-', '-', '▓', '-', '█', '-', '█', '-', '-', '█',},
                        {'█', '-', '-', '-', '-', '█', '█', '█', '█', '-', '█', '-', '-', '█',},
                        {'█', '-', '█', '█', '█', '-', 'B', 'I', '█', '-', '█', '-', '-', '█',},
                        {'█', '-', '█', '-', '█', '-', '█', '-', '█', '█', '█', '-', '-', '█',},
                        {'█', '-', '█', '-', '-', '-', '█', '-', '-', '-', '-', '-', '-', '█',},
                        {'█', 'I', '█', '█', '-', '-', '█', '-', '-', '-', '-', '-', '-', '█',},
                        {'█', '█', '█', '█', '█', '█', '█', '█', '█', '█', '█', '█', '█', '█',}
                };
                spawnThief('N', 12, 11, "Key");        //thief will drop a key
                spawnThief('N', 4, 8, "");
                break;
        }
        currentMaze = Arrays.copyOf(baseMaze,baseMaze.length);
    }
    public static void spawnThief(char direction, int col, int row, String storedItem) {        //For spawning thieves (Can have as many as you want)
        if (T == null) {
            T = new ArrayList<>();
        }
        GameData.Thief newThief = new GameData.Thief();
        newThief.direction = direction;         //sets their stats to given
        newThief.ThiefCol = col;
        newThief.ThiefRow = row;
        newThief.storedItem = storedItem;
        T.add(newThief);
    }
    public static void loadCurrentMaze() {
        for (int i = 0; i < currentMaze.length; i++) {     //prints the selected maze
            for (int j = 0; j < currentMaze[0].length; j++) {
                boolean thiefSpawn = false;
                if (i == Pl.currentRow && j == Pl.currentCol) {     //prints player pos
                    System.out.print("P");
                    continue;
                }
                if (i == B.currentRow && j == B.currentCol) {           //prints bomb pos
                    if (B.duration >= 2) {
                        System.out.print(Gm.RedColor + "B" + Gm.ResetColor);
                    }
                    else if (B.duration == 1) {
                        System.out.print(Gm.DarkRedColor + "B" + Gm.ResetColor);
                    }
                    continue;
                }
                if (T != null) {
                    for (GameData.Thief thief : T) {            //prints ALl thief pos (If 2+ thieves are on one tile, then only prints 1)
                        if (i == thief.ThiefRow && j == thief.ThiefCol && !thiefSpawn) {
                            if (!thief.storedItem.isEmpty()) {
                                System.out.print(Gm.BlueColor + "T" + Gm.ResetColor);
                            } else {
                                System.out.print("T");
                            }
                            thiefSpawn = true;
                        }
                    }
                }
                if(currentMaze[i][j] == 'F') {          //makes the falling ceiling appear invisible (but stored as F internally)
                    currentMaze[i][j] = '-';
                    fallingCeilling[0] = i;
                    fallingCeilling[1] = j;
                }
                if (!thiefSpawn) {
                    System.out.print(currentMaze[i][j]);            //prints whatever else isn't listed here
                }
            }
            System.out.println();
        }
    }
    public static void validPosition(char choice) {         //tests for valid position (So the player can't move through walls)
        switch (choice) {
            case 'A':           //A (Left)
                if (Pl.currentCol - 1 >= 0 && Gm.passable(currentMaze, Pl,0,-1,"Reg")) {
                    Pl.currentCol -= 1;
                    Pl.restoreStamina(Pl.staminaRegen);
                }
                break;
            case 'W':           //W (Up)
                if (Pl.currentRow - 1 >= 0 && Gm.passable(currentMaze, Pl,-1,0,"Reg")) {
                    Pl.currentRow -= 1;
                    Pl.restoreStamina(Pl.staminaRegen);
                }
                break;
            case 'S':           //S (Down)
                if (Pl.currentRow + 1 < currentMaze.length && Gm.passable(currentMaze, Pl,1,0,"Reg")) {
                    Pl.currentRow += 1;
                    Pl.restoreStamina(Pl.staminaRegen);
                }
                break;
            case 'D':           //D (Right)
                if (Pl.currentCol + 1 < currentMaze[0].length && Gm.passable(currentMaze, Pl,0,1,"Reg")) {
                    Pl.currentCol += 1;
                    Pl.restoreStamina(Pl.staminaRegen);
                }
                break;
        }
    }
    public static void Items() {            //Item menu
        while (true) {
            int drop = 0;
            int back = 1;
            System.out.println("Items:");
            if (!Pl.item1.isEmpty()) {
                System.out.println("[1] " + Pl.item1);
                drop++;
                back++;
            }
            if (!Pl.item2.isEmpty()) {
                System.out.println("[2] " + Pl.item2);
                drop++;
                back++;
            }
            if (!Pl.item1.isEmpty()) {          //if player has no items, this won't show up
                drop++;
                System.out.println("[" + drop + "] Drop Item");
                back++;
            }
            System.out.println("[" + back + "] Back");          //back = highest option number + 1
            int choice = validInput(sc);
            if (!Pl.item1.isEmpty() && choice == 1) {
                Gm.useItem(Pl, Pl.item1, currentMaze, 1, T);
                break;
            }
            else if (!Pl.item2.isEmpty() && choice == 2) {
                Gm.useItem(Pl, Pl.item2, currentMaze, 2, T);
                break;
            }
            else if (choice == drop && drop != 0) {
                if (currentMaze[Pl.currentRow][Pl.currentCol] == '-') {
                    dropItem();
                }
                else {
                    System.out.println("You can't drop an item here! Please move to an open space to drop an item!");
                }
                break;
            }
            else if (choice == back) {
                GameData.clearScreen();
                break;
            }
            else {
                System.out.println("Please enter a different number.");
            }
        }
    }
    public static void dropItem() {         //dropping items
        while (true) {
            System.out.println("Which item will you drop?");
            int back = 1;
            if (!Pl.item1.isEmpty()) {
                System.out.println("[1] " + Pl.item1);
                back++;
            }
            if (!Pl.item2.isEmpty()) {
                System.out.println("[2] " + Pl.item2);
                back++;
            }
            System.out.println("[" + back + "] Back");
            int choice = validInput(sc);
            if (!Pl.item1.isEmpty() && choice == 1) {
                Gm.dropItem(Pl, Pl.item1, currentMaze);
                Pl.item1 = "";
                if (!Pl.item2.isEmpty()) {
                    Pl.item1 = Pl.item2;
                    Pl.item2 = "";
                }
                break;
            }
            else if (!Pl.item2.isEmpty() && choice == 2) {
                Gm.dropItem(Pl, Pl.item2, currentMaze);
                Pl.item2 = "";
                break;
            }
            else if (choice == back) {
                break;
            }
        }
    }
    public static void massMove() {         //For the mass movement option
        while (Pl.stamina > 0) {
            sc.nextLine();
            System.out.println("Enter a list of movements in the directions you want to go (AWSD), or type B to go back: ");
            String mass = sc.nextLine().toUpperCase();
            char[] movements = mass.toCharArray();
            int moveCounter;
            try {
                moveCounter = movements.length;
                if (movements[0] == 'B') {      //If the first character is B (or b) due to b being made upperCase, go back to game()
                    GameData.clearScreen();
                    break;
                } else if (Gm.validMovement(movements)) {
                    B.duration -= 1;
                    if (T != null) {
                        Gm.thiefMovement(T, currentMaze);
                        Gm.thiefPickup(T, currentMaze);
                    }
                    for (char c : movements) {
                        if ((Pl.currentCol == fallingCeilling[1]) && (Pl.currentRow == fallingCeilling[0]) && Gm.ActiveCeilingTrap) { //check for trap at current location (so the player can't mass move through it)
                            Gm.FallingCeiling(Pl);
                            if(Pl.health <= 0) {
                                Pl.killer = "fallingCeilling";
                                break;
                            }
                            loadCurrentMaze();
                        }
                        switch (c) {
                            case 'A':           //A (Left)
                                if (Pl.currentCol - 1 >= 0 && Gm.passable(currentMaze, Pl, 0, -1, "Mass")) {
                                    Pl.currentCol -= 1;
                                } else {
                                    Pl.takeDamage(moveCounter*5);
                                    System.out.println("You have taken serious damage from mass moving!");
                                    Pl.useStamina(moveCounter);
                                    return;
                                }
                                break;
                            case 'W':           //W (Up)
                                if (Pl.currentRow - 1 >= 0 && Gm.passable(currentMaze, Pl, -1, 0, "Mass")) {
                                    Pl.currentRow -= 1;
                                } else {
                                    Pl.takeDamage(moveCounter*5);
                                    System.out.println("You have taken serious damage from mass moving!");
                                    Pl.useStamina(moveCounter);
                                    return;
                                }
                                break;
                            case 'S':           //S (Down)
                                if (Pl.currentRow + 1 < currentMaze.length && Gm.passable(currentMaze, Pl, 1, 0, "Mass")) {
                                    Pl.currentRow += 1;
                                } else {
                                    Pl.takeDamage(moveCounter*5);
                                    System.out.println("You have taken serious damage from mass moving!");
                                    Pl.useStamina(moveCounter);
                                    return;

                                }
                                break;
                            case 'D':           //D (Right)
                                if (Pl.currentCol + 1 < currentMaze[0].length && Gm.passable(currentMaze, Pl, 0, 1, "Mass")) {
                                    Pl.currentCol += 1;
                                } else {
                                    Pl.takeDamage(moveCounter*5);
                                    System.out.println("You have taken serious damage from mass moving!");
                                    Pl.useStamina(moveCounter);
                                    return;
                                }
                                break;
                        }
                    }
                    Pl.useStamina(moveCounter);
                    break;
                } else {
                    System.out.println("Please only enter 'A', 'W', 'S', or 'D' in the movement list!\nExample: \"AAWWD\" (left, left, up, up, right)");
                }
            }
            catch (Exception e) {
                System.out.println("Please only enter 'A', 'W', 'S', or 'D' in the movement list!\nExample: \"AAWWD\" (left, left, up, up, right)");
            }
        }
        System.out.println("You are too tired to mass move, try walking around to restore stamina!");
    }
    public static void game() {
        B.duration = -1;
        if (T != null) {
            T.clear();          //clears thieves from past levels/reload levels
        }
        loadBaseMaze();     //loads the base maze for playing (also copies to currentMaze[][] for printing and playing)
        while (Pl.health > 0) {
            if (B.duration == 0) {          //for if a bomb will explode
                System.out.println(Gm.DarkRedColor + "A nearby Bomb has detonated!" + Gm.ResetColor);
                Gm.detonateBomb(currentMaze, Pl);       //updates breakable tiles
                B.duration -= 1;
                B.currentCol = -1;
                B.currentRow = -1;          //(-1,-1) is the default place for bombs not in use
                if (Pl.health <= 0) {           //player can lose health in Gm.detonateBomb
                    Pl.health = 0;
                    Pl.killer = "bomb";
                    break;
                }
            }
            if (T != null) {
                for (GameData.Thief thief : T) {            //goes through all thieves
                    if (Pl.currentRow == thief.ThiefRow && Pl.currentCol == thief.ThiefCol) {
                        System.out.println("The nearby thief has slashed you with a dagger!");
                        Pl.takeDamage(3);
                        if (Pl.health <= 0) {
                            Pl.health = 0;
                            Pl.killer = "thief";
                            break;
                        }
                    }
                }
            }
            loadCurrentMaze();
            if ((Pl.currentCol == fallingCeilling[1]) && (Pl.currentRow == fallingCeilling[0]) && Gm.ActiveCeilingTrap) { //check for trap at current location
                Gm.FallingCeiling(Pl);
                if(Pl.health <= 0) {
                    Pl.killer = "fallingCeilling";
                    break;
                }
                loadCurrentMaze();
        }
            int overlapItemID = 0;
            if (B.duration > 0) {       //for bombs ready to detonate
                if (B.currentRow == Pl.currentRow && B.currentCol == Pl.currentCol) {
                    System.out.println(Gm.DarkRedColor + "The bomb you are standing on will detonate in " + B.duration + " move" + (B.duration > 1 ? "s" : "") + "!" + Gm.ResetColor);

                }
                else {
                    System.out.println(Gm.RedColor + "A nearby Bomb will detonate in " + B.duration + " move" + (B.duration > 1 ? "s" : "") + "!" + Gm.ResetColor);

                }
            }
            System.out.println("Health: " + Pl.health + "%\t\tStamina: " + Pl.stamina + "%");        //Displays HP and Stamina
            /*System.out.println("Coords: ("+ Pl.currentRow + "),(" + Pl.currentCol + ")");
            System.out.println("Bomb Coords: ("+ B.currentRow + "),(" + B.currentCol + ")");
            int thiefCount = 1;
            for (GameData.Thief thief : T) {
                System.out.println("-------------");
                System.out.println("Thief " + thiefCount + " Coords: (" + thief.ThiefRow + "),(" + thief.ThiefCol + ")");
                System.out.println("Thief " + thiefCount + " Facing Direction: " + thief.direction);
                System.out.println("Falling Ceiling Coords: (" + fallingCeilling[0] + "),(" + fallingCeilling[1] + ")");
                thiefCount ++;
            }*/
            System.out.println("Enter your choice, or press A,W,S,D to move");
            switch (currentMaze[Pl.currentRow][Pl.currentCol]) {            //if the player is on an item
                case 'V':
                    System.out.println(Gm.BlueColor + "You found a Potion of Vigor! Enter 4 to pick it up!" + Gm.ResetColor);
                    overlapItemID = 1;
                    break;
                case 'K':
                    System.out.println(Gm.BlueColor + "You found a Key! Enter 4 to pick it up!" + Gm.ResetColor);
                    overlapItemID = 2;
                    break;
                case 'B':
                    System.out.println(Gm.BlueColor + "You found a Bomb! Enter 4 to pick it up!" + Gm.ResetColor);
                    overlapItemID = 3;
                    break;
                case 'I':
                    System.out.println(Gm.BlueColor + "You found a Pickaxe! Enter 4 to pick it up!" + Gm.ResetColor);
                    overlapItemID = 4;
                    break;
                case 'O':
                    System.out.println(Gm.BlueColor + "The door is open! Enter 0 to go through it!" + Gm.ResetColor);
                    overlapItemID = 5;
                    break;
            }
            if (overlapItemID == 5){
                System.out.println(Gm.BlueColor + "[0] Go through door" + Gm.ResetColor);
            }
            System.out.println("[1] Mass Move");
            System.out.println("[2] Items");
            System.out.println("[3] Options");
            if (overlapItemID > 0 && overlapItemID < 5) {
                System.out.println(Gm.BlueColor + "[4] Pick up Item" + Gm.ResetColor);
            }
            String c = sc.next().toUpperCase();
            if (c.isEmpty()) {
                System.out.println("Please enter a character or number!");
                continue;
            }
            char choice = c.charAt(0);
            switch (choice) {
                case 'A':
                case 'W':
                case 'S':
                case 'D':           //for regular (Non-mass) moving
                    GameData.clearScreen();
                    B.duration -= 1;
                    validPosition(choice);
                    if (T != null) {
                        Gm.thiefMovement(T, currentMaze);
                        Gm.thiefPickup(T, currentMaze);
                    }
                    break;
                case '1':
                    massMove();     //doesn't clearScreen so the player can see the maze as they're mass moving
                    break;
                case '2':
                    GameData.clearScreen();
                    Items();
                    break;
                case '3':
                    if (options() == 1) {
                        return;
                    }
                    break;
                case '4':       //if the player is staning on an item (does not appear otherwise)
                    if (overlapItemID > 0) {
                        Gm.addItem(overlapItemID, Pl, currentMaze);
                    }
                    else {
                        System.out.println("Please enter a different character!");
                    }
                    break;

                default:
                    System.out.println("Please enter a different character!");
                    break;
                case '0':
                    if (overlapItemID==5) {
                        switchLVL();
                    }
                    else {
                        System.out.println("Please enter a different character!");
                    }
                    break;
            }
        }
        if (Pl.health <= 0) {
            Death(0, Pl.killer);       //no other way to get here if you don't die by massmove, bomb, thief, etc
        }
    }
    public static int options() {
        while (true) {
            GameData.clearScreen();
            System.out.println("Options: ");
            System.out.println("[1] Reset Level");
            System.out.println("[2] Quit Game");
            System.out.println("[3] Back");
            int choi = validInput(sc);
            switch (choi) {
                case 1:
                    System.out.println("Reseting Game..");
                    int LVL = Pl.LVL;       //stores LVL through reset
                    Pl.setBaseStats();
                    Pl.LVL = LVL;
                    GameData.clearScreen();
                    if (T != null) {
                        T.clear();          //clears thieves from past levels/reload levels
                    }
                    Pl.basePosition(Pl, Pl.LVL);        //sets basePosition once more
                    Gm.ActiveCeilingTrap = true;        //re-activates any unactive falling ceilings
                    loadBaseMaze();
                    return 0;
                case 2:
                    GameData.clearScreen();
                    System.out.println("Back to Main Menu...");
                    return 1;           //1 if returning to main()
                case 3:
                    GameData.clearScreen();
                    return 0;               //0 if not returning to main()
                default:
                    GameData.clearScreen();
                    System.out.println("Please enter a different number.");
            }
        }
    }

    public static void resetPlayer() { //player reset to starting point after death
        System.out.println("\n\nYou awaken and see that you have returned to the same spot where you fell into the maze");
        Gm.ActiveCeilingTrap = true;        //resets falling ceiling
        int TempLVL = Pl.LVL;           //stores level for reset
        Pl.setBaseStats();
        Pl.LVL = TempLVL;
        Pl.basePosition(Pl, Pl.LVL);
        game();
    }

    //Function must be called each time player takes damage
    public static void Death(int health, String killer) {    //Checks if player is dead, killer is cause of death
        if(health == 0) {
            if (T != null) {
                T.clear();
            }
            System.out.println("\t\tYou have died");
            switch(killer) {
                case "wallmass":        //if you die by Mass movement
                    System.out.println("You ran into the wall!");
                    break;
                case "wallreg":         //if you die by regular movement
                    System.out.println("You have hit the wall!");
                    break;
                case "rollingBall":         //if you die by rolling ball
                    System.out.println("You were crushed by a large rolling ball");
                    break;
                case "fallingCeilling":     //if you die by falling ceiling
                    System.out.println("You were flattened by a falling ceiling");
                    break;
                case "bomb":        //if you die by a bomb
                    System.out.println("You were blown up by a bomb!");
                    break;
                case "thief":       //if you die by a thief
                    System.out.println("You have been slashed by the thief!");
                    break;
                case "minotaur":        //if you die by a minotaur
                    System.out.println("You have been mauled by the Minotaur");
                    break;
            }
            while (true) {
                sc.nextLine();      //absorbs newline character
                System.out.println("\tType ok to continue");
                String okInput = sc.nextLine();
                if(okInput.equals("ok"))
                    break;
            }
            resetPlayer();
        }
    }
    //function called when hovering over open door to show next level title screen and go to next maze level
    public static void switchLVL() {
        GameData.clearScreen();
        Pl.LVL++;
        String fileName;
        if (Pl.LVL == 2) {
            //prints the title screen for level 2
            fileName = "lvltwo.txt";
            while (true) {
                try {
                    BufferedReader reader = new BufferedReader(new FileReader(fileName));
                    String line;
                    while ((line = reader.readLine()) != null) {
                        System.out.println(line);
                    }
                    reader.close();
                } catch (Exception e) {     //if .txt file is not there in directory just print text
                    System.out.println("YOU ARE NOW ENTERING LEVEL 2! WATCH OUT FOR THE THEIVES");
                }
                //click 1 to continue
                System.out.println("[1] continue");
                int cont = validInput(sc);
                if (cont == 1){
                    Pl.basePosition(Pl, Pl.LVL);
                    loadBaseMaze();
                    GameData.clearScreen();  //opens new level
                    break;
                }
            }
        }

        else if (Pl.LVL == 3) {
            //prints level 3 title screen
            fileName = "lvlthree.txt";
            while (true) {
                try {
                    BufferedReader reader = new BufferedReader(new FileReader(fileName));
                    String line;
                    while ((line = reader.readLine()) != null) {
                        System.out.println(line);
                    }
                    reader.close();
                } catch (Exception e) {     //if file not found then just print the text
                    System.out.println("YOU ARE NOW ENTERING LEVEL 3!");
                }
                //click 1 to continue
                System.out.println("[1] continue");
                int cont = validInput(sc);
                if (cont == 1){
                    Pl.basePosition(Pl, Pl.LVL);
                    loadBaseMaze();
                    GameData.clearScreen();
                    break;
                }
            }
        }

        else if (Pl.LVL == 4) {// wins game
            //prints winning screen
            fileName = "youwin.txt";
            while (true) {
                try {
                    BufferedReader reader = new BufferedReader(new FileReader(fileName));
                    String line;
                    while ((line = reader.readLine()) != null) {
                        System.out.println(line);
                    }
                    reader.close();
                } catch (Exception e) {     //if titletext.txt is not there in directory
                    System.out.println("CONGRATULATIONS! YOU HAVE WON THE GAME!");
                }
                //click 1 to exit program
                System.out.println("[1] Exit");
                int cont = validInput(sc);
                if (cont == 1){
                    System.exit(0);
                }
            }
        }
    }
    public static void main(String[] args) {
        while (true) {
            try {
                BufferedReader reader = new BufferedReader(new FileReader("titletext.txt"));
                String line;
                while ((line = reader.readLine()) != null) {        //prints line by line
                    System.out.println(line);
                }
                reader.close();
            } catch (Exception e) {     //if titletext.txt is not there in directory
                System.out.println("Failed to load titletext.txt, Please ensure title.txt is located in the same directory!");
            }
            Pl.setBaseStats();
            System.out.println("Main Menu");
            System.out.println("Enter your choice (Type the corresponding number, then press enter)");
            System.out.println("[1] Start Game");
            System.out.println("[2] Tutorials");
            System.out.println("[3] Quit");
            int choi = validInput(sc);
            switch (choi) {
                case 1:     //start game
                    GameData.clearScreen();
                    System.out.println("Starting Game..");
                    Pl.basePosition(Pl, Pl.LVL);
                    game();
                    break;
                case 2:
                    tutorial();
                    break;
                case 3:                             //quit
                    System.exit(0);
            }
        }
    }
    public static void tutorial() {
        int choi;
        while (true) {
            GameData.clearScreen();
            System.out.println("---Tutorials---");
            System.out.println("Select an option to learn about it");
            System.out.println("[1] Navigating the maze");
            System.out.println("[2] Mass Movement");
            System.out.println("[3] Bombs");
            System.out.println("[4] Thieves");
            System.out.println("[5] Falling Ceilings");
            System.out.println("[6] Health and Stamina");
            System.out.println("[7] Items");
            System.out.println("[8] Structure of Programming");
            System.out.println("[9] Back");
            choi = validInput(sc);
            sc.nextLine();
            switch (choi) {
                case 1:
                    GameData.clearScreen();
                    System.out.println("---Navigating the Maze---");
                    System.out.println("To navigate the maze, the player may type:");
                    System.out.println("A: Move left");
                    System.out.println("W: Move up");
                    System.out.println("S: Move down");
                    System.out.println("D: Move right");
                    System.out.println("In the maze, the player may come across obstacles such as walls and thieves or helpful tools like keys and Potion of Vigor!");
                    System.out.println("The player's position is denoted by a \"P\" on the map which shows where the player currently is");
                    System.out.println("The type of walls are as follows: ");
                    System.out.println("\n█: Standard Wall, cannot be broken nor passed through by anything");
                    System.out.println("▓: Breakable wall, can be blown up with bombs");
                    System.out.println("X: Key Door, a key can be used on this to turn it into an exit point");
                    System.out.println("M: Minotaur, a fiecesome beast that deals lots of damage when walked into. Can be destroyed with a bomb");
                    break;
                case 2:
                    GameData.clearScreen();
                    System.out.println("---Mass Movement---");
                    System.out.println("Mass movement is a feature that lets the player move multiple spaces in one go");
                    System.out.println("To mass move, the player selects the mass movement and then is prompted to enter a string of movements like this:");
                    System.out.println("\nSystem.out.println(\"Enter a list of movements in the directions you want to go (AWSD), or type B to go back: \");");
                    System.out.println("PLAYER: awwdds\n");
                    System.out.println("The game will take this string of characters and convert each character in a move. So in this case, the player will move: ");
                    System.out.println("Left-Up-Up-Right-Right-Down");
                    System.out.println("All of this will occur in an instant and consume stamina");
                    break;
                case 3:
                    GameData.clearScreen();
                    System.out.println("---Bombs---");
                    System.out.println("Bombs are an item that appear in Maze game and are denoted by a B on the map");
                    System.out.println("To get a bomb, the player must pick up a bomb like any item by standing on it and pressing 4 when prompted");
                    System.out.println("The player can then go to items and use the bomb, in which it will drop a bomb object in the maze");
                    System.out.println("The bomb will then detonate in 3 moves, either by regular movement (AWSD) or by mass movement");
                    System.out.println("It will also give warning signs that look like this in gameplay as the player moves around");
                    System.out.println(Gm.RedColor + "\nA nearby Bomb will detonate in 3 moves" + Gm.ResetColor);
                    System.out.println(Gm.RedColor + "A nearby Bomb will detonate in 2 moves" + Gm.ResetColor);
                    System.out.println(Gm.RedColor + "A nearby Bomb will detonate in 1 move\n" + Gm.ResetColor);
                    System.out.println("Once the bomb explodes, it will dissapear from the map and will blow up any breakable walls (▓)");
                    break;
                case 4:
                    GameData.clearScreen();
                    System.out.println("---Thieves---");
                    System.out.println("Thieves are unqiue objects that actively move around the maze");
                    System.out.println("Thievs are denoted by the letter T on the maze and every time you move, they also move");
                    System.out.println("If a thief happens to come across an item, they will pick it up and turn " + Gm.BlueColor + "blue" + Gm.ResetColor);
                    System.out.println("To get the item back, the player must use the pickaxe item to attack them and they will drop the item");
                    System.out.println("Thieves have very special movement properties to ensure they don't get stuck in a corner.");
                    System.out.println("Thieves are also not programmed on a specialized path and will randomly choose a direction to go if multiple options are present");
                    System.out.println("The amount of thieves per level are not limited");
                    break;
                case 5:
                    GameData.clearScreen();
                    System.out.println("---Falling Ceiling---");
                    System.out.println("Falling ceiling are a unique event where the player will be thrusted into a special do-or-die event");
                    System.out.println("Falling ceilings will appear invisible on the map unitl the player steps on it, once then they will be forced to answer a riddle");
                    System.out.println("If the player guesses the riddle correctly, they can proceed through the maze, if not, they will instantly die");
                    System.out.println("Mass movement cannot be used to run past the falling ceiling");
                    System.out.println("Falling ceilings have 6 random riddles to choose from and the answer isn't super strict");
                    System.out.println("For example, if the answer is \"Horse\", the player can say \"a horse\" or \"HORSES\" and all 3 will be counted correct");
                    break;
                case 6:
                    GameData.clearScreen();
                    System.out.println("---Health and Stamina---");
                    System.out.println("Health and Stamina are vital components to Maze game that can dictate whether you make it through a maze or not");
                    System.out.println("Health and Stamina are always shown to the player");
                    System.out.println("\nHealth has a maximum of 100 and a minimum of 0");
                    System.out.println("Stamina has a maximum of 100 but can be negative\n");
                    System.out.println("If the player's health reaches 0, they will die and the maze level will reset");
                    System.out.println("If the player's stamina reaches 0, they will take a little damage and will be locked out of mass movement until it's greater than 0");
                    System.out.println("Health can be restored with Potions of Vigor");
                    System.out.println("Stamina can be slowly restored by regularly moving around");
                    break;
                case 7:
                    GameData.clearScreen();
                    System.out.println("---Items---");
                    System.out.println("Items play a key role in Maze Game and are required to beat it");
                    System.out.println("Maze Game features 4 different items");
                    System.out.println("\nPotions of Vigors: Restores health by 50, denoted by a \"V\" on the map");
                    System.out.println("Keys: Used to open key doors (X), denoted by a \"K\" on the map");
                    System.out.println("Bombs: Can be used to place a bomb, is denoted by a white \"B\" on the map (NOT the bomb object which is red)");
                    System.out.println("Pickaxes, Can be used to defeat thieves, is denoted by a \"I\" on the map");
                    break;
                case 8:
                    GameData.clearScreen();
                    System.out.println("---Structure of Programming---");
                    System.out.println("Maze Game features 3 .java files: Main.java, GameData.java, and Player.Java");
                    System.out.println("\nMain.java is the biggest file and features the core components of the game, such as the title screen, current maze layout, item menu, mass movement menu, and keeps track of public variables like the scanner");
                    System.out.println("\nPlayer.java is the smallest file and features the player's stats and alike. It contains the player's health and stamina, functions to restore health and stamina, and taking away health and stamina");
                    System.out.println("\nGameData.java is the 2nd biggest file and features the core functions of the game. This file allows the game to function with functions such as detecting if the player will hit a wall, the bomb countdown, falling ceiling functionality, and thief movements");
                    break;
                case 9:
                    return;
                default:
                    System.out.println("Please enter a different number.");
            }
            System.out.println("Press Enter to continue");
            sc.nextLine();
        }
    }
    public static int validInput(Scanner sc) {          //so the user doesn't kamikaze at the first input, might use later for items
        while (!sc.hasNextInt()) {
            System.out.println("Please enter a number (Not including decimals)!");
            sc.next();          //consumes invalid input
        }
        return sc.nextInt();
    }
}
